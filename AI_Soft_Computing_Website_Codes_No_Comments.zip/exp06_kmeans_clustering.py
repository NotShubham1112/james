import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

data = {
    'Name': ['Aarav', 'Priya', 'Rohan', 'Ananya', 'Vikram', 'Meera', 'Rahul', 'Neha'],
    'Income': [350000, 500000, 420000, 1200000, 300000, 950000, 400000, 1100000]
}

df = pd.DataFrame(data)
model = KMeans(n_clusters=2, random_state=0, n_init=10)
df['Cluster'] = model.fit_predict(df[['Income']])

print("Cluster 0:")
print(df[df['Cluster'] == 0][['Name', 'Income']])

print("\nCluster 1:")
print(df[df['Cluster'] == 1][['Name', 'Income']])

plt.scatter(df['Name'], df['Income'], c=df['Cluster'], cmap='viridis')
plt.xlabel('Name')
plt.ylabel('Annual Income (INR)')
plt.title('Income Clusters')
plt.show()

def alpha_beta(depth, index, is_max, alpha, beta):
    if depth == 3:
        return values[index]

    if is_max:
        best = alpha
        for i in range(2):
            value = alpha_beta(depth + 1, index * 2 + i, False, alpha, beta)
            best = max(best, value)
            alpha = max(alpha, best)
            if alpha >= beta:
                break
        return best

    best = beta
    for i in range(2):
        value = alpha_beta(depth + 1, index * 2 + i, True, alpha, beta)
        best = min(best, value)
        beta = min(beta, best)
        if alpha >= beta:
            break
    return best


alpha = float('-inf')
beta = float('inf')
values = [2, 3, 5, 9, 0, 1, 7, 5]
result = alpha_beta(0, 0, True, alpha, beta)
print("Optimal Value =", result)

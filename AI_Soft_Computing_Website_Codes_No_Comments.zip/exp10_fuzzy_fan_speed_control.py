import numpy as np


def triangular(x, a, b, c):
    if x <= a or x >= c:
        return 0
    elif x == b:
        return 1
    elif x < b:
        return (x - a) / (b - a)
    else:
        return (c - x) / (c - b)


temperature_input = int(input("Enter temperature (°C): "))

if temperature_input < 1:
    speed = 0
    print("\nFuzzy Control Output")
    print("Temperature :", temperature_input, "°C")
    print("Fan Speed   : 0%")
    print("Fan Status  : OFF")
else:
    low = triangular(temperature_input, 1, 10, 20)
    medium = triangular(temperature_input, 15, 25, 35)
    high = triangular(temperature_input, 25, 40, 50)

    print("\nTemperature Membership Values:")
    print("Low    :", round(low, 2))
    print("Medium :", round(medium, 2))
    print("High   :", round(high, 2))

    total = low + medium + high
    if total != 0:
        speed = (low * 25 + medium * 50 + high * 100) / total
    else:
        speed = 0

    print("\nFuzzy Control Output")
    print("Temperature :", temperature_input, "°C")
    print("Fan Speed   :", round(speed, 2), "%")

    if speed <= 35:
        print("Fan Status  : Slow")
    elif speed <= 70:
        print("Fan Status  : Medium")
    else:
        print("Fan Status  : Fast")

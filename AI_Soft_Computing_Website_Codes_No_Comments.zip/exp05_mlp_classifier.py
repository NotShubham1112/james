from sklearn.neural_network import MLPClassifier

X = [
    [20, 20000],
    [25, 25000],
    [30, 30000],
    [35, 40000],
    [40, 50000],
    [45, 60000]
]
y = [0, 0, 0, 1, 1, 1]

model = MLPClassifier(hidden_layer_sizes=(5,), max_iter=2000)
model.fit(X, y)

age = int(input("Enter age: "))
income = int(input("Enter income: "))
result = model.predict([[age, income]])

if result[0] == 1:
    print("Prediction: Customer will BUY")
else:
    print("Prediction: Customer will NOT BUY")
